@extends('frontends.layouts.main')

@section('main-container')
<main>
</main>
@endsection