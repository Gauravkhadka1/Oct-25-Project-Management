<div id="main-container" class="main-container">
      @include('frontends.layouts.header')
      @yield('main-container')
      @include('frontends.layouts.footer')
    </div>