<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<!-- jQuery library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- Caret.js - Required for At.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.caret/0.3.1/jquery.caret.min.js"></script>

<!-- At.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.atwho/1.3.0/js/jquery.atwho.min.js"></script>

<!-- Your custom At.js initialization file -->
<script src="{{ url('frontend/js/at.js') }}"></script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="{{ url('frontend/js/usernamemention.js') }}"></script>


</body>
</html>