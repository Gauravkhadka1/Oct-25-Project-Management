<!DOCTYPE html>
<html>
<head>
    <title>New Mention Notification</title>
</head>
<body>
    <h1>You have been mentioned!</h1>
    <p>{{ $mentionMessage }}</p>
</body>
</html>
